/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: regulateur.c
Module: Régulation de température et générateur de consigne PWM
Binome: Amandine ROGER, Guillaume LAURENT-BURLE
*/

#include <msp430f149.h>
#include <math.h>
#include <stdio.h>
#include "tmp101.h"
#include "regulateur.h"
#include "tmp101.h"
#include "rs232.h"

/* Alias pour l'utilisation du matériel */
#define DRV593_SHDN 	BIT3
#define DRV593_LED	BIT1

#define DRV593		P1OUT
#define DRV593_DIR 	P1DIR

/* Variables globales */
unsigned char marche;
unsigned char chauffage;
unsigned char TorOrPid;
float TConsigne;

float prev_erreur;
float integrale;
float dt;
float prev_temp;

/* Initialisation du module de régulation */
void REG_Init()
{
	DRV593_DIR |= ( DRV593_SHDN | DRV593_LED );
	DRV593 &= ~DRV593_SHDN;
	DRV593 |= DRV593_LED;
	
	marche = 0;	

	return;
}

/* Remise à 0 des valeurs du PID */
void REG_PidClear() {
	prev_erreur = 0;
	integrale = 0;
	dt = 0;
	prev_temp = 0;
}

/* Allumage de la régulation, et du driver Peltier */
void REG_OnOff()
{

/* Le chauffage/refroidissement ne sera déclenché que 
si le module est en marche */
	if ( marche == 1 ) {
		DRV593 &= ~DRV593_LED;
		DRV593 |= DRV593_SHDN;
		REG_PidClear();
	}
	else {	
		DRV593 &= ~DRV593_SHDN;
		DRV593 |= DRV593_LED;
		REG_PidClear();
	}	

	return;
}

/* Application de la commande */
void REG_Consigne(int cons)
{	
	if (abs(cons) < 249 )
		CCR1 = 250 + cons;
	else
		if ( cons > 0 )		
			CCR1 = 490;
		else
			CCR1 = 10;

}

/* Regulation tout ou rien */
void REG_Tor(float cons) {

/* Récupération de la température courante */
	CurrentTemp = TMP101_ReadTemp();

/* Choix du comportement de du module */
	if ( chauffage ) {
/* Tout ou rien en chaleur */
		if ( cons > CurrentTemp )
		{
			REG_OnOff();
			REG_Consigne(150);
		}
		else
		{
	 		REG_Consigne(0);
		}
	} 
	else {
/* Tout ou rien en refroidissement */
		if ( cons < CurrentTemp )
		{
			REG_OnOff();
			REG_Consigne(-150);
		}
		else
		{
	 		REG_Consigne(0);

		}
	}
	return;

}

/* Boucle ouverte, requis pour calibrer PID */
void REG_BoucleOuverte(int cons)
{
	REG_OnOff();
	CurrentTemp = TMP101_ReadTemp();
	REG_Consigne(cons);
	return;
}

/* Regulation PID*/
void REG_Pid(float cons)
{

	char tmpStr[10];
	CurrentTemp = TMP101_ReadTemp();

// ZIEGLER NICHOLS
// FACTEUR PROPORTIONNEL			
	float Cp = 27.520;

// FACTEUR INTEGRAL
	float Ci = 18.25;

// FACTEUR DERIVE
	float Cd = 1.131;


	float dt = 0.301; //3915.5;
	float erreur = cons - CurrentTemp;
	integrale = integrale + erreur*dt;
	float derive = (prev_erreur - erreur);

// NE PAS EFFECTUER DE DIVISION D'UN NOMBRE TROP PETIT
	if ( fabs(derive) > 10e-4 ) 
		derive = derive/dt;
	else
		derive = 0.0;

// CALCUL DE LA CONSIGNE
	int sortie = ( (Cp*erreur) + (Ci*integrale) + (Cd*derive) );//*0.3219;
	
// TRANSMISSION CONSIGNE PID
	REG_OnOff();
	REG_Consigne(sortie);

// SAUVEGARDE DE LA VALEUR AVANT LE NOUVEL APPEL DE LA BOUCLE PID	
	prev_erreur = erreur;

	return;


}
