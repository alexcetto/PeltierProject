/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: pwm.c
Module: Générateur de signaux PWM
Binome: Amandine ROGER, Guillaume LAURENT-BURLE
*/

#include <msp430f149.h>

void PWM_Init(void) {
	
/* Initlisation du composant gérant la commande PWM */
	P1DIR |= BIT2;				// Confiugration du port 
	P1SEL |= BIT2;				// P1.2
	CCR0 = 500-1;				// PWM Period 
	CCTL1 = OUTMOD_7;			// CCR1 reset/set 
	CCR1 = 250;				// Rapport cyclique 1/2 
	TACTL = TASSEL_2 + MC_1;

	return;

}


