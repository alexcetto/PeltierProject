/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: peltier.c
Module: Programme principal
Binome: Amandine ROGER, Guillaume LAURENT-BURLE
*/

/* Inclusions */
#include <msp430f149.h>
#include <string.h>
#include <math.h>
#include "rs232.h"
#include "tmp101.h"
#include "libs/SPLC501C.h"
#include "ECRAN_polytech.h"
#include "pwm.h"
#include "regulateur.h"

/* Boucle de programme princpal */
void main(void) {
	
	int i;
	char temp_str[20];
	char cons_str[20];		

  	WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
 	
/* Appel des initialisation des différents modules */
	PWM_Init();
	GLCD_Initialize();
	REG_Init();

/* Valeurs par défaut */	
	OperationMode = 1;
	TConsigne = 50;	
	TorOrPid = 1;

/* Affichage du logo de Polytech Marseille */
	GLCD_WriteCommand(SPLC501C_DISPLAY_OFF);
	GLCD_ClearScreen();
	GLCD_Bitmap(ecran_mini_pol,25,0,132,64);
	GLCD_GoTo(3,3);
	GLCD_WriteString10x16("POLYTECH");
	GLCD_GoTo(3,5);
	GLCD_WriteString("Marseille");
	GLCD_WriteCommand(SPLC501C_DISPLAY_ON);

/* Fin des Initilisations */
	TMP101_Init();	
	REG_PidClear();
	RS232_Init();

/* Boucle de programme */
	while (1) {
		
		if ( OperationMode ) {
			float2str(TConsigne, cons_str);			
			strcat(cons_str, "\x7F\x43  " );
			GLCD_GoTo(3,1);
			GLCD_WriteString(cons_str);
			
		}
		else {
			RS232_SendString(temp_str);
			RS232_SendString(" C\r\n");
		}
		
		if ( TorOrPid )
			REG_Pid(TConsigne);
		else
			REG_Tor(TConsigne);

/* AFFICHAGE DE LA TEMPRATURE SUR L'ECRAN LCD */
		float2str(CurrentTemp, temp_str);
		strcat(temp_str, "\x7F\x43  " );
		GLCD_GoTo(3,7);
		GLCD_WriteString(temp_str);	

	}
	

}
