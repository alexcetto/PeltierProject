/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: rs232.c
Module: Pilote RS232
Binome: Amandine ROGER, Guillaume LAURENT-BURLE
*/

#include <msp430f149.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "tmp101.h"
#include "libs/SPLC501C.h"
#include "rs232.h"
#include "regulateur.h"
#include "libs/SPLC501C.h"

/* Mode d'opérations : 0 ASCII Console, 1 Piloté par application */
unsigned char OperationMode = 0;

/* Requis pour le fonctionnement des fonctions entre plusieur appels */
static char string1[50];
char ii = 0;
char jj = 0;

/* Boucle d'attente pour controller que les buffers RS232 ont bien étés
vidés */
void rs232_delay(unsigned int ms)
{
	unsigned int i, j;
	for (i = 0; i <= ms; i++)
	{
		for (j = 0; j<=255; j++);
	}
}


/* Fonction d'envoi d'une chaine sur le port RS232 */
void RS232_SendString(char *pszChaine) {
	
	char *tmp = pszChaine;

/* Tant que le caratctère 0 n'est pas rencontré on envoie les données */  	
	while ( *tmp ) {
		while (!UTXIFG0);	/* Attente buffer vide */		
		TXBUF0 = *tmp;
		rs232_delay(1);
		tmp++;
	}

} 

/* Fonction d'envoi d'un char sur le port RS232 */
void RS232_SendChar(unsigned char c) {

	while (!UTXIFG0);	/* Attente avec interruption a verifier */		
	TXBUF0 = c;
	rs232_delay(1);

}

/* Initialisation du port de communication RS232 */
void RS232_Init(void)
{

/* Code générique source: ti.com, adapté pour notre aplication */
	P3SEL = 0x30;                             // P3.3,4 = USART0 TXD/RXD
 	ME1 |= UTXE0 + URXE0;                     // Enabled USART0 TXD/RXD
	UCTL0 |= CHAR;                            // 8-bit character, SWRST=1
	UTCTL0 |= SSEL0;                          // UCLK = ACLK
 	UBR00 = 0x03;                             // 9600 from 1Mhz
 	UBR10 = 0x00;                             //
 	UMCTL0 = 0x4A;                            // Modulation
 	UCTL0 &= ~SWRST;                          // Initialize USART state machine
 	IE1 |= URXIE0 + UTXIE0;                   // Enable USART0 RX/TX interrupt
 	IFG1 &= ~UTXIFG0;                         // Clear inital flag on POR

/* Ajout des leds d'activité RS232 */
 	P6DIR |= 0x70;			    	// Leds pour actitvité RS232
 	P6OUT = 0x00;

/* Activation des interruptions */ 
  	_BIS_SR(GIE);		

}

/* Gestion en mode caractère */
void ReceiveCharCommand(unsigned char rData) {

/* Détection de la touche "ENTREE" */
	if ( rData == 0x0D ) {

		RS232_SendString("\r\n");	
		RS232_SendString(string1);
		GLCD_GoTo(6,6);
		GLCD_WriteString(string1);
		RS232_SendString("\r\n");
	  	string1[0] = 0x00;
		jj = 0;

/* Marche Arret/Regulation */
		if ( marche == 0 ) {
			GLCD_GoTo(3,1);
			RS232_SendString("Marche\r\n");
			marche = 1;
		}
		else {
			marche = 0;
			RS232_SendString("Arret\r\n");
		}
	}

/* Renvoi du caractère à la console */
	string1[jj++] = rData;
	string1[jj] = 0x00; 
	TXBUF0 = rData;
}

/* Gestion en mode commande */
void ReceiveCommand(unsigned char rData) {

	char temp_str[20];
	float temp;

/* Switch de gestion des commandes */
	switch (rData) {

/* Marche */
		case 0xF0:
			marche = 0;
			break;
/* Arret */
		case 0xF1:
			marche = 1;
			break;
/* RAZ Buffer */
		case 242:
			string1[jj] = 0x00;
			jj = 0;
			break;
/* Regulation TOR */
		case 0xF3:
			TorOrPid = 0;
			break;

/* Regulation PID */
		case 0xF4:
			TorOrPid = 1;
			break;

/* Definition de la consigne de température */
		case 0xF5:
			/* Valeurs entières pour l'instant */			
			TConsigne = atoi(string1);
			if ( CurrentTemp < TConsigne )
				chauffage = 1;
			else
				chauffage = 0;
			string1[jj] = 0x00;
			jj = 0;
			break;

/* Lecture de la température courante */			
		case 0xF6:			
			RS232_SendString(CurrentTempStr);
			break;

/* Sotckage dans des commandes dans le buffer */
		default:
			string1[jj++] = rData;
			string1[jj] = 0x00;
			break;
	}

}

// UART0 TX ISR
#pragma vector=UART0TX_VECTOR
__interrupt void usart0_tx (void)
{

/* Faire clignoter la led */
	P6OUT ^= 0x10;
	rs232_delay(1);
	P6OUT ^= 0x10;

}

// UART0 RX ISR
#pragma vector=UART0RX_VECTOR
__interrupt void usart0_rx (void)
{

/* Faire clignoter la led */
	P6OUT ^= 0x20;

/* Gestion commande console ou logiciel de pilotage */
	if (OperationMode) {
		ReceiveCommand(RXBUF0);
	}
	else {
		ReceiveCharCommand(RXBUF0);
	}

	rs232_delay(1);
	P6OUT ^= 0x20;

}


