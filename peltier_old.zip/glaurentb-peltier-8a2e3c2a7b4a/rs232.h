/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: rs232.h
Module: Pilote RS232
Binome: Amandine ROGER, Guillaume LAURENT-BURLE
*/

#ifndef _RS232_H_
#define _RS232_H_

void RS232_SendString(char *pszChaine);
void RS232_SendChar(unsigned char c);
void RS232_delay(unsigned int ms);
void RS232_Init(void);

extern unsigned char OperationMode;

#endif
