/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: regulateur.h
Module: Générateur de signaux PWM
Binome: Amandine ROGER, Guillaume LAURENT-BURLE
*/

#ifndef _REG_H_
#define _REG_H_

void REG_Init();
void REG_OnOff();
void REG_Tor(float);
//void REG_TorRefrodissement(float);
void REG_Pid(float);
//void REG_BoucleOuverte(int cons);
//void REG_PChauffage(float);

extern unsigned char marche;
extern unsigned char TorOrPid;
extern unsigned char chauffage;
extern float TConsigne;
extern float erreur;
extern float integrale;
extern float dt;
extern float prev_temp;



#endif //_REG_H
