/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: tmp101.c
Module: Programme principal
Binome: Amandine ROGER, Guillaume LAURENT-BURLE

************************************************************************
GESTION DU PROTOCOLE I2C
***********************************************************************/

/* Version MSP430F149 */
#include <msp430f149.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "libs/i2c.h"

// Addresses potielles des périphériques
#define TMP101_ADDR0W		0x90
#define TMP101_ADDR0R		0x91
#define TMP101_ADDR1W		0x92
#define TMP101_ADDR1R		0x93
#define TMP101_ADDR2W		0x94
#define TMP101_ADDR2R		0x95

// Registres du TMP101
#define TMP101_TEMP_REG		0x00
#define TMP101_CONF_REG		0x01
#define TMP101_TLOW_REG		0x02
#define TMP101_THIGH_REG	0x03

// Combinaisons de configuration du TMP101
#define TMP101_OS_ALERT		0x80
#define TMP101_09BIT_RES	0x00
#define TMP101_10BIT_RES	0x20
#define TMP101_11BIT_RES	0x40
#define TMP101_12BIT_RES	0x60
#define TMP101_01FAULTS		0x00
#define TMP101_02FAULTS		0x08
#define TMP101_04FAULTS		0x10
#define TMP101_06FAULTS		0x18
#define TMP101_POL_LOW		0x00
#define TMP101_POL_HIGH		0x04
#define TMP101_TM_CMP		0x00
#define TMP101_TM_INT		0x02
#define TMP101_SHUTDOWN		0x01
#define TMP101_NO_SHUTDOWN	0x00

/* Incréments en fonction de la réslution de température */
#define _09BIT_RES_INC		0.5
#define _10BIT_RES_INC		0.25
#define _11BIT_RES_INC		0.125
#define _12BIT_RES_INC		0.0625

#define _09BIT_RES_SHIFT	3
#define _10BIT_RES_SHIFT	2
#define _11BIT_RES_SHIFT	1
#define _12BIT_RES_SHIFT	0

float CurrentTemp = 0;
char CurrentTempStr[10] = "";

/* Conversion d'un float vers un string */
void float2str(float num, char *fstr) {
	
	int ent = floor(num);
	float d = num - ent;
	int dec = floor(100*d);
	if ( num < 0 )
		strcat("-",fstr);
	if ( dec < 10 )
		sprintf(fstr,"%d.0%d",ent,dec);
	else 
		sprintf(fstr,"%d.%d",ent,dec);

}


/* Initilisation du module TMP101 */
void TMP101_Init(void) {
	
	unsigned char tmp101_config[] = {0x00, 0x00};
	
/* Definition de la commande de configuration du TMP101 */	
	tmp101_config[0] |= ( TMP101_12BIT_RES | TMP101_POL_HIGH | TMP101_NO_SHUTDOWN );	

/* Intialisation des ports en envoi de la commande */
	I2C_InitializePorts();
	I2C_SendCommand(TMP101_ADDR2W, TMP101_CONF_REG, tmp101_config);

	return;

}

float TMP101_ReadTemp(void) {

	int i, j, length, tmp;
	float temp;
	char temp_str[80];
	char signe;
	
	unsigned char tmp101_str[] = {0x00, 0x00};

// 		Début de séquence séquence I2C
	I2C_Start();	// SDA = LOW, SCL = HIGH

//		Send Address
	I2C_WriteByte(TMP101_ADDR2W);
	i = I2C_GetAck();	

//		Send register address
	I2C_WriteByte(TMP101_TEMP_REG);
	i = I2C_GetAck();

	I2C_Start();
	I2C_WriteByte(TMP101_ADDR2R);
	i = I2C_GetAck();

//		Read bytes
	j = 0;
	length = 2;
	while ( ( j<length ) && !i ) {
		tmp101_str[j] = I2C_ReadByte();
		I2C_SendAck();
		j++;
	}

//		Fin de séquence I2C
	I2C_Stop();

/* Recomposition de la valeur brute à partir de données du TMP101 */
	tmp = 0;
	temp = 1.0;
	signe = 0x80 & tmp101_str[0];
	tmp101_str[0] &= ~0x80;
	tmp |= (tmp101_str[1] >> 4) | ( (int)tmp101_str[0] << 4  ); 			
	tmp >>= _12BIT_RES_SHIFT;	
	if ( signe ) tmp |= 0xF800;	
	temp = tmp;
	temp = temp * _12BIT_RES_INC;

/* Conversion de la valeur en chaine de caractères */
	float2str(temp,	CurrentTempStr);

	return temp;
}

