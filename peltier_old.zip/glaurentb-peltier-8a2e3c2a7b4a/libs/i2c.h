/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: i2c.h
Module: Programme principal
Binome: Amandine ROGER, Guillaume LAURENT-BURLE

************************************************************************
GESTION DU PROTOCOLE I2C
***********************************************************************/

#ifndef _I2C_H_
#define _I2C_H_ 

void I2C_Stop(void);
void I2C_Start(void);
void I2C_InitializePorts(void);
void I2C_WriteByte(unsigned char I2C_Byte);
unsigned char I2C_ReadByte(void);
int I2C_GetAck(void);
void I2C_SendCommand(unsigned char I2C_Address, unsigned char I2C_Register, char* I2C_DataString );
void I2C_ReadData(unsigned char I2C_Address, unsigned char I2C_Register, char *I2C_DataBuffer, int length );

#endif
