/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: SPLC510C-MSP430F149.c
Module: Programme principal
Binome: Amandine ROGER, Guillaume LAURENT-BURLE

************************************************************************
 Commandes du SPLC501C
************************************************************************
Port P4.1 (A0P_LCP):
 Commande: A0P = 0
 Données: A0P = 1
 Note: Valeur lue tous les 8 fronts montants

Port P4.0 (SCL_LCD):
 Serial Clock Input
 Note: Horloge serie pour la communicaiton avec l'afficheur

Port P4.4 (CS1_N_LCD):
 Chip Select (CS) (attention, acif au niveau bas "CS barre")
 Valeurs:
 - Chip activé CS1_N_LCD = 0
 - Chip désactivé CS1_N_LCD = 1

Port P2.2 (SI_LCD):
 Serial Data Input (SI)
 La valeur transmise sur le port est lue chaque front montant de SCL

Port P4.5 (RESET_N_LCD):
 Reset (RESET) (Attention, actif au niveau bas "RESET barre")
 Valeurs:
  - Afficheur réinitialisé RESET_N_LCD = 0
  - Afficheur en fonctionnement RESET_N_LCD = 1

Note: Il n'y a pas de limite d'horloge en fréquence basse, nous pouvons
donc générer une horloge que quand on en a besoin
***********************************************************************/

/* Version MSP430F149 */
#include <msp430f149.h>

/* Pour test */
#include "../rs232.h"

/* Definition de macros pour la gestion des ports du MSP430 */
#define SPLC501C_SI		0x04 // P2.2 = SI_LCD (Serial Input)
#define SPLC501C_SCL		0x01 // P4.0 = SCL_LCD (Serial CLock)
#define SPLC501C_A0P		0x02 // P4.1 = A0P_LCP (Active OPeration)
#define SPLC501C_CS1 		0x10 // P4.4 = CS1_N_LCD (Chip Select)
#define SPLC501C_RST 		0x20 // P4.5 = RESET_N_LCD (Reset)

/* Macros de configuration des ports */
#define SPLC501C_CMD		P4OUT // P4 = LCD DISPLAY COMMAND PORT
#define SPLC501C_DAT		P2OUT // P2 = LCD DISPLAY DATA PORT
#define SPLC501C_CMD_DIR	P4DIR // P4 I/O Configuration 
#define SPLC501C_DAT_DIR	P2DIR // P2 I/O Configuration

#define SPLC501C_CLK_LED	0x04
#define SPLC501C_ACT_LED	0x08

//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
void GLCD_InitializePorts(void)
{	
	volatile int i;

	/* Intialisation des ports du MSP430F149 */
	/* Les autres pates ne seront pas affectés */
	_BIC_SR(GIE);		/* Désactivation des interruptions */ 
	SPLC501C_CMD_DIR |= SPLC501C_SCL; 
	SPLC501C_CMD_DIR |= SPLC501C_A0P; 
	SPLC501C_CMD_DIR |= SPLC501C_CS1; 
	SPLC501C_CMD_DIR |= SPLC501C_RST;
	SPLC501C_CMD_DIR |= SPLC501C_CLK_LED;
	SPLC501C_CMD_DIR |= SPLC501C_ACT_LED;
	
	SPLC501C_DAT_DIR |= SPLC501C_SI;
	
	/* Exctinction des leds d'activité */
	SPLC501C_CMD &= ~SPLC501C_CLK_LED;
	SPLC501C_CMD &= ~SPLC501C_ACT_LED;

	/* Activation du circuit SPLC510C CS1=0*/
	SPLC501C_CMD &= ~SPLC501C_CS1;
	SPLC501C_CMD |= SPLC501C_SCL;

	/* Envoi d'un RESET à l'afficheur */
	SPLC501C_CMD &= ~SPLC501C_A0P;
	SPLC501C_CMD |= SPLC501C_RST;
	for(i = 0 ; i < 1000; i++);	
	SPLC501C_CMD &= ~SPLC501C_RST;
	for(i = 0 ; i < 1000; i++);
	SPLC501C_CMD |= SPLC501C_RST;

	_BIS_SR(GIE); /* Activation des interruptions */ 
}
/* Innutile de traduire les fonctions en parallèle car le SPLC501C est utilisé en série (voir doc p. 11)
 et est donc en communication unidirectionnelle avec le MSP430F149 */

//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
void GLCD_WriteData(unsigned char dataToWrite)
{
	/* Locales */	
	volatile int i,j;
	unsigned char tmp;

	/* Mise à 1 de la ligne A0P_LCD (Envoi de données) et de l'horloge série */
	SPLC501C_CMD |= SPLC501C_A0P;
	SPLC501C_CMD |= SPLC501C_SCL;

	/* Bloucle de transmission en série */
	tmp=0x00;
	i=7;
	while ( i >= 0 ) {
		
		/* RAZ du bit à transmettre */
		SPLC501C_DAT &= ~SPLC501C_SI;
		SPLC501C_CMD &= ~SPLC501C_ACT_LED;

		/* Récupération du bit à transmettre */		
		tmp = dataToWrite >> i;
		tmp &= 0x01;		
		SPLC501C_CMD |= (tmp << 3);	
		tmp=tmp << 2;

		/* Chargement de la valeur dans le registre */		
		SPLC501C_DAT |=  tmp;	
		
		/* Top d'horloge */
		SPLC501C_CMD &= ~SPLC501C_SCL;	// LOW
		SPLC501C_CMD |= SPLC501C_SCL; 	// HIGH

		i--;

	}

	SPLC501C_DAT &= ~SPLC501C_SI;

}
//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
void GLCD_WriteCommand(unsigned char commandToWrite)
{

	/* Locales */	
	volatile int i,j;
	unsigned char tmp;

	/* Mise à 0 de la ligne A0P_LCD (Envoi de commande) et 0 à l'horloge série */
	SPLC501C_CMD &= ~SPLC501C_A0P;
	SPLC501C_CMD |= SPLC501C_SCL;

	/* Bloucle de transmission en série */
	tmp=0x00;
	i=7;
	while ( i >= 0 ) {

		/* RAZ du bit à transmettre */
		SPLC501C_DAT &= ~SPLC501C_SI;
		SPLC501C_CMD &= ~SPLC501C_ACT_LED;

		/* Récupération du bit à transmettre */		
		tmp=commandToWrite >> i;
		tmp &= 0x01;		
		SPLC501C_CMD |= (tmp << 3);
		//RS232_SendChar(0x30 + tmp);		
		tmp=tmp << 2;

		/* Chargement de la valeur dans le registre */		
		SPLC501C_DAT |=  tmp;
		
		/* Top d'horloge */
		SPLC501C_CMD &= ~SPLC501C_SCL;	// LOW
		SPLC501C_CMD |= SPLC501C_SCL; 	// HIGH		
		i--;

	}

	/* Blink led */
	SPLC501C_DAT &= ~SPLC501C_SI;
	
	return;
}
