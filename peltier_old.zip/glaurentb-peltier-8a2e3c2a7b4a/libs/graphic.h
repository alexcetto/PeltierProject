// Wy�wietlacz graficzny ze sterownikiem S6B0724
// sterowanie w jezyku C od podstaw
// Plik : graphic.h
// Autor : Rados�aw Kwiecie�

void GLCD_Rectangle(unsigned char x, unsigned char y, unsigned char b, unsigned char a);
void GLCD_Circle(unsigned char cx, unsigned char cy ,unsigned char radius);
void GLCD_Line(int X1, int Y1,int X2,int Y2);
