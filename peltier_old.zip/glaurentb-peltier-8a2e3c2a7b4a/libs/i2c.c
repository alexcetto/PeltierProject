/*
  _____      _       _            _       _____   _____    __  __   
 |  __ \    | |     | |          | |     |_   _| |  __ \  |  \/  |  
 | |__) |__ | |_   _| |_ ___  ___| |__     | |   | |__) | | \  / |  
 |  ___/ _ \| | | | | __/ _ \/ __| '_ \    | |   |  _  /  | |\/| |  
 | |  | (_) | | |_| | ||  __/ (__| | | |  _| |_ _| | \ \ _| |  | |_ 
 |_|   \___/|_|\__, |\__\___|\___|_| |_| |_____(_)_|  \_(_)_|  |_(_)
                __/ |                                               
               |___/

Projet: Effet Peltier
Fichier: i2c.c
Module: Programme principal
Binome: Amandine ROGER, Guillaume LAURENT-BURLE

************************************************************************
GESTION DU PROTOCOLE I2C
***********************************************************************/

/* Version MSP430F149 */
#include <msp430f149.h>
#include "../rs232.h"

/* Definition de macros pour la gestion des ports du MSP430 */
#define TMP101_SDA		0x20 // P1.5 = TMP101_SDA (Serial DAta)
#define TMP101_SCL		0x40 // P1.6 = TMP101_SCL (Serial CLock)
#define TMP101_ALERT		0x80 // P1.7 = TMP101_ALERT 

/* Macros de configuration des ports */
#define TMP101			P1OUT // P1 = TMP 101 PORT
#define TMP101_IN		P1IN
#define TMP101_DIR		P1DIR // P1 = TMP 101 PORT

#define CPU_F ((double)5060000)
#define _delay_us(x) __delay_cycles((long)(CPU_F*(double)x/1000000.0))
#define _delay_ms(x) __delay_cycles((long)(CPU_F*(double)x/1000.0))


/* Envoi de la commande I2C start */
void I2C_Start(void) {
	
	_BIC_SR(GIE);		/* Désactivation des interruptions */ 

	//RS232_SendString("\n\rI2C_Start ");
	
//				LIGNES EN SORTIE
	TMP101_DIR |= ( TMP101_SDA | TMP101_SCL );

	TMP101 |= TMP101_SDA;	// SDA = 1
	_delay_us(5);
	TMP101 |= TMP101_SCL;	// SCL = 1
	_delay_us(5);
	TMP101 &= ~TMP101_SDA;	// SDA = 0
	_delay_us(5);

	TMP101 &= ~TMP101_SCL; 	// SCL = 0
	_delay_us(5);

	_BIS_SR(GIE); /* Activation des interruptions */ 
	
	return;
}

/* Envoi de la commande I2C stop */
void I2C_Stop(void) {

	_BIC_SR(GIE);		/* Désactivation des interruptions */ 
	
//				LIGNES EN SORTIE
	TMP101_DIR |= ( TMP101_SDA | TMP101_SCL );

	TMP101 &= ~TMP101_SCL; 	// SCL = 0
	_delay_us(5);
	TMP101 &= ~TMP101_SDA;	// SDA = 0
	_delay_us(5);
	TMP101 |= TMP101_SCL;	// SCL = 1
	_delay_us(5);
	TMP101 |= TMP101_SDA;	// SDA = 1
	_delay_us(5);

	_BIS_SR(GIE); /* Activation des interruptions */ 
	
	return;
}

/* Initilisation des ports du microcontroleur pour la gestion I2C */
void I2C_InitializePorts(void)
{	
	volatile int i;

	/* Intialisation des ports du MSP430F149 */
	/* Les autres pates ne seront pas affectés */
	_BIC_SR(GIE);		/* Désactivation des interruptions */ 
	
	TMP101_DIR |= ( TMP101_SCL | TMP101_ALERT ); // SCL_OUT
	TMP101_DIR &= ~TMP101_SDA; 	// SDA_IN
	TMP101 &= ~TMP101_ALERT;	

	TMP101 &= ~TMP101_SDA; 
	TMP101 &= ~TMP101_SCL;		// SCL = 0

	I2C_Stop();

	_BIS_SR(GIE); /* Activation des interruptions */ 
}

/* Ecriture d'un octet sur le bus I2C */
void I2C_WriteByte(unsigned char I2C_Byte) {

	/* Locales */	
	volatile int i,j;
	unsigned char tmp;

	_BIC_SR(GIE);		/* Désactivation des interruptions */ 

//				LIGNES EN SORTIE
	TMP101_DIR |= ( TMP101_SDA | TMP101_SCL );

	/* Bloucle de transmission en série */
	tmp=0x00;
	i=7;
	while ( i >= 0 ) {
		
		TMP101_DIR |= TMP101_SDA;	// SDA OUT
		
		/* Récupération du bit à transmettre */		
		tmp = I2C_Byte >> i;
		tmp &= 0x01;		
		if ( tmp ) {
			TMP101 |= TMP101_SDA;
		}		
		else {		
			TMP101 &= ~TMP101_SDA;
		}
	
		/* Top d'horloge */
		_delay_us(10);
		TMP101 |= TMP101_SCL; 	// HIGH
		_delay_us(5);
		TMP101 &= ~TMP101_SCL;	// LOW
		_delay_us(10);

		i--;

	}

//				LIGNES EN ENTREE
	TMP101_DIR &= ~TMP101_SDA;
	_delay_us(5);

	_BIS_SR(GIE); /* Activation des interruptions */ 
}

/* Lecture d'un octet sur le bus I2C */
unsigned char I2C_ReadByte(void) {

	/* Locales */	
	unsigned char tmp;
	unsigned char ret;
	int i;

	_BIC_SR(GIE);		/* Désactivation des interruptions */ 

//				LIGNES EN ENTREE
	TMP101_DIR &= ~TMP101_SDA;
// 				SCL HIGH
	TMP101 |= TMP101_SCL; 	
//				LIGNES EN SORTIE
	TMP101_DIR |= TMP101_SCL;	
	
	
	/* Bloucle lecture de données en série */
	tmp=0x00;
	ret=0x00;
	i=7;
	while ( i >= 0 ) {

		/* Top d'horloge */
		TMP101 |= TMP101_SCL; 	// HIGH	
		_delay_us(10);
	
		/* Récupération du bit lu */		
		tmp = TMP101_IN >> 5;
		tmp &= 0x01;
		ret |= tmp << i;
		_delay_us(10);		
		TMP101 &= ~TMP101_SCL;	// LOW
		_delay_us(10);	

		i--;

	}

	_BIS_SR(GIE); /* Activation des interruptions */ 

	return ret;

}

/* Lecture ACK ou NACK sur le bus I2C */
int I2C_GetAck (void) {
	
	volatile int Ack;

	_BIC_SR(GIE);		/* Désactivation des interruptions */ 

//				LIGNES EN ENTREE
	TMP101_DIR &= ~TMP101_SDA;
//				LIGNES EN SORTIE
	TMP101_DIR |= TMP101_SCL;

	_delay_us(5);
	TMP101 |= TMP101_SCL;	// SCL = 1
	_delay_us(5);
	Ack = ( (TMP101_IN & TMP101_SDA) == TMP101_SDA );	// RECUP ACK
	_delay_us(5);
	TMP101 &= ~TMP101_SCL; 	// SCL = 0
	_delay_us(5);
	
	_BIS_SR(GIE); /* Activation des interruptions */ 
				
	return Ack;

}

/* Envoi de la commande I2C ACK */
void I2C_SendAck(void) {
	
	volatile int Ack;

	_BIC_SR(GIE);		/* Désactivation des interruptions */ 

//				LIGNES EN SORTIE
	TMP101_DIR |= ( TMP101_SDA | TMP101_SCL );

	TMP101 &= ~TMP101_SDA;	// SDA = 0
	_delay_us(5);
	TMP101 |= TMP101_SCL;	// SCL = 1
	_delay_us(5);
	TMP101 &= ~TMP101_SCL; 	// SCL = 0
	_delay_us(5);
	TMP101 |= TMP101_SDA;	// SDA = 1
	_delay_us(5);

	_BIS_SR(GIE); /* Activation des interruptions */ 
				
	return;

}

/* Envoi de la commande I2C NACK */
void I2C_SendNack(void) {
	
	volatile int Ack;

	_BIC_SR(GIE);		/* Désactivation des interruptions */ 

//				LIGNES EN SORTIE
	TMP101_DIR |= ( TMP101_SDA | TMP101_SCL );

	TMP101 |= TMP101_SDA;	// SDA = 1
	_delay_us(5);
	TMP101 |= TMP101_SCL;	// SCL = 1
	_delay_us(5);
	TMP101 &= ~TMP101_SCL; 	// SCL = 0
	_delay_us(5);

	_BIS_SR(GIE); /* Activation des interruptions */ 
				
	return;

}

/* Envoi d'une commande I2C */
void I2C_SendCommand(unsigned char I2C_Address, unsigned char I2C_Register, char* I2C_DataString )
{
	/* Locales */	
	volatile int i,j;
	unsigned char tmp;

	_BIC_SR(GIE);		/* Désactivation des interruptions */ 

// Début de séquence séquence I2C
	I2C_Start();	// SDA = LOW, SCL = HIGH

// Envoi adresse
	I2C_WriteByte(I2C_Address);
	i = I2C_GetAck();	

// Envoi adresse registre
	I2C_WriteByte(I2C_Register);
	i = I2C_GetAck();

// Envoi des commandes
	while ( *I2C_DataString && !i ) {
		I2C_WriteByte(*I2C_DataString);
		I2C_DataString++;
		i = I2C_GetAck();
	}
// Fin de séquence I2C
	I2C_Stop();

	_BIS_SR(GIE); /* Activation des interruptions */ 

}

