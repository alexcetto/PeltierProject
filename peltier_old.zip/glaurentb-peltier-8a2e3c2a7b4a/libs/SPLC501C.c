#include "SPLC501C.h"
#include "font5x7.h"
#include "font10x16.h"
#include "SPLC501C-MSP430F149.c"

extern void GLCD_WriteCommand(unsigned char);
extern void GLCD_WriteData(unsigned char);
//extern unsigned char GLCD_ReadData(void);
extern void GLCD_InitializePorts(void);

unsigned int gfx1_x,gfx1_y;

//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
void GLCD_Initialize(void)
{
volatile int i;
	GLCD_InitializePorts();

	_BIC_SR(GIE);
	GLCD_WriteCommand(SPLC501C_ADC_NORMAL);					
	GLCD_WriteCommand(SPLC501C_COM63);	

	GLCD_WriteCommand(SPLC501C_BIAS_19);						
	GLCD_WriteCommand(SPLC501C_POWERON);						
	for(i = 0; i < 100; i++);
	GLCD_WriteCommand(SPLC501C_VOLUME_MODE);						
	GLCD_WriteCommand(SPLC501C_VOLUME_SET | 10);	/* Réglage du contraste */
	GLCD_WriteCommand(0xA4);						
	//GLCD_WriteCommand(SPLC501C_DISPLAY_ON);						
	GLCD_WriteCommand(SPLC501C_DISPLAY_NORMAL);		
	GLCD_WriteCommand(SPLC501C_PAGE_ADDRESS | 0);
	GLCD_WriteCommand(SPLC501C_COLUMN_ADDRESS_HI | 0);		
	GLCD_WriteCommand(SPLC501C_COLUMN_ADDRESS_LO | 0);
	GLCD_WriteCommand(SPLC501C_START_LINE | 0);	

	gfx1_x=0;//emulation memoire ecran
    	gfx1_y=0;//emulation memoire ecran
	_BIS_SR(GIE);
}
//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
void GLCD_GoTo(unsigned char x, unsigned char y)
{
	_BIC_SR(GIE);
	GLCD_WriteCommand(SPLC501C_COLUMN_ADDRESS_HI | (x >> 4));
	GLCD_WriteCommand(SPLC501C_COLUMN_ADDRESS_LO | (x & 0x0F));
	GLCD_WriteCommand(SPLC501C_PAGE_ADDRESS | y);
	gfx1_x=x;//emulation memoire ecran
	gfx1_y=y;//emulation memoire ecran
	_BIS_SR(GIE);
}
//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
void GLCD_ClearScreen(void)
{
_BIC_SR(GIE);
unsigned char x = 0, y = 0;
for(y = 0; y < (SCREEN_HEIGHT/PIXELS_PER_PAGE); y++)
	{
	GLCD_GoTo(0,y);
	for(x = 0; x < SCREEN_WIDTH; x++)
		{
		GLCD_WriteData(0);
		}
	}
_BIS_SR(GIE);
}		
//-------------------------------------------------------------------------------------------------
// Function : GLCD_WriteChar
// Artuments : Char ASCII code
// Return value : none
//-------------------------------------------------------------------------------------------------
void GLCD_WriteChar(char charCode)
{
	unsigned char fontCollumn;
	for(fontCollumn = 0; fontCollumn < FONT_WIDTH; fontCollumn++)
	GLCD_WriteData(font5x7[((charCode- FONT_OFFSET) * FONT_WIDTH) + fontCollumn]);
	GLCD_WriteData(0);
}

//-------------------------------------------------------------------------------------------------
// Function : GLCD_WriteChar10x16
// Artuments : Char ASCII code
// Return value : none
//-------------------------------------------------------------------------------------------------
void GLCD_WriteChar10x16(char charCode) {
    unsigned int fontCollumn;
    unsigned int x,y;

    y=gfx1_y;
    x=gfx1_x;
    for (fontCollumn = 0; fontCollumn < FONT_WIDTH10x16; fontCollumn+=2) {
        GLCD_GoTo(x,y);
        GLCD_WriteData(font10x16[((charCode- FONT_OFFSET10x16)  * FONT_WIDTH10x16) + fontCollumn]);
        GLCD_GoTo(x,y+1);
        GLCD_WriteData(font10x16[((charCode- FONT_OFFSET10x16)  * FONT_WIDTH10x16) + fontCollumn + 1]);
        x++;
    }
    GLCD_WriteData(0);
    GLCD_GoTo(x,y);
}
//-------------------------------------------------------------------------------------------------
// Function : GLCD_WriteString
// Arguments : pointer to null-terminated ASCII string
// Return value : none
//-------------------------------------------------------------------------------------------------
void GLCD_WriteString(char * string)
{
_BIC_SR(GIE);
while(*string)
  {
  GLCD_WriteChar(*string++);
  }
_BIS_SR(GIE);
}
//-------------------------------------------------------------------------------------------------
// Function : GLCD_WriteString10x16
// Arguments : pointer to null-terminated ASCII string
// Return value : none
//-------------------------------------------------------------------------------------------------
void GLCD_WriteString10x16(char * string) {
_BIC_SR(GIE);
    while (*string) {
        GLCD_WriteChar10x16(*string++);
    }
_BIS_SR(GIE);
}
// !!! Innexploitable en mode série SPLC501C !!!
//-------------------------------------------------------------------------------------------------
// Function : GLCD_SetPixel
// Arguments : x-location, y-location, color (0 or 1)
// Return value : None
//-------------------------------------------------------------------------------------------------
/*void GLCD_SetPixel(int x, int y, int color)
{
unsigned char temp = 0;  
GLCD_GoTo(x, (y/8)); 
temp = GLCD_ReadData(); 
if(color)
  temp |= (1 << (y % 8));
else
  temp &= ~(1 << (y % 8));
GLCD_GoTo(x, (y/8)); 
GLCD_WriteData(temp); 
}*/
//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
void GLCD_Bitmap(const unsigned char * bitmap,unsigned char left, unsigned char top, unsigned char width, unsigned char height)
{
_BIC_SR(GIE);
unsigned char pageIndex, columnIndex;
for(pageIndex = 0; pageIndex < height / 8; pageIndex++)
  {
  GLCD_GoTo(left, top + pageIndex);
  for(columnIndex = 0; columnIndex < width; columnIndex++)
    GLCD_WriteData(*(bitmap++)); 
  }
_BIS_SR(GIE);
}
//-------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
